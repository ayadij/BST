#pragma once

#include "NodeInterface.h"

class Node : public NodeInterface
{

public:

	Node(int data);
	~Node();

	int data;
	Node* leftchild;
	Node* rightchild;

private:

	int getData();
	Node* getLeftChild();
	Node* getRightChild();


};
